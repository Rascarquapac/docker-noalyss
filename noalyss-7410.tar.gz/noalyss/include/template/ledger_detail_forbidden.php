<?php
//This file is part of NOALYSS and is under GPL 
//see licence.txt
?><div style="margin:0;padding:0;background-color:red;text-align:center;">
<h2 class="error"><?php echo _("Accès interdit : vous n'avez pas accès à cette information, contactez votre responsable")?></h2>;
</div>
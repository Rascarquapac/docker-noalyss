<?php
//This file is part of NOALYSS and is under GPL 
//see licence.txt
?>
<?php echo _('Partie du poste comptable ou du libellé'); ?>
<?php echo $str_poste?>
<?php echo $str_submit?>
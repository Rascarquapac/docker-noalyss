<?php
$a_result = 
array (
  0 => 
  array (
    'tva_label' => '21%',
    'qs_vat_code' => '1',
    'tva_rate' => '0.2100',
    'tva_both_side' => '0',
    'amount_vat' => '16.8000',
    'amount_wovat' => '80.0000',
    'amount_sided' => '0.0000',
    'tva_payment_sale' => 'P',
  ),
  1 => 
  array (
    'tva_label' => 'VOIT',
    'qs_vat_code' => '1003',
    'tva_rate' => '0.2100',
    'tva_both_side' => '0',
    'amount_vat' => '10.7500',
    'amount_wovat' => '51.2000',
    'amount_sided' => '0.0000',
    'tva_payment_sale' => 'P',
  ),
);

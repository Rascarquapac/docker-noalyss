<?php

/*
 *   This file is part of NOALYSS.
 *
 *   NOALYSS is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   NOALYSS is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with NOALYSS; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Copyright Author Dany De Bontridder danydb@aevalys.eu

/*
 * Global variables
 */
global $g_connection,$g_parameter,$g_user;
define ("DOSSIER",48);
$_REQUEST['gDossier'] = DOSSIER;
$g_connection=new Database(DOSSIER);
$g_parameter = new Noalyss_Parameter_Folder($g_connection);
$_SESSION['g_user']='phpcompta';
$_SESSION['g_pass']='dany';
$_SESSION['g_pagesize']='50';
$g_user=new User($g_connection);

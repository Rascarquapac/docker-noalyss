update menu_ref set me_menu='Journal' where me_code='CFGLED';


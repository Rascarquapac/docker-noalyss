/* This file is part of NOALYSS and is under GPL see licence.txt */
content[50]="le taux est compris entre 0 et 100";
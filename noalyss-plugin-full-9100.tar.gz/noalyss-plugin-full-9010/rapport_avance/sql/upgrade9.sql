begin;
insert into rapport_advanced.type_row (p_type,p_description) values (10,'Titre');
update rapport_advanced.type_row set p_description='Titre 1er Niveau' where p_type=1;
insert into rapport_advanced.version(version_id,version_note) values (9,'Add Main Title');
commit;
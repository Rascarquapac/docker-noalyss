
function tva_parameter_modify(p_tva)
{waiting_box();new Ajax.Request("ajax.php",{parameters:{tva_id:p_tva,gDossier:dossier,plugin_code:plugin_code,ac:ac,action:"tva_parameter_modify"},method:"get",onSuccess:function(req)
{var obj={id:'tva_detail_id',"cssclass":"inner_box","style":"width:auto;position:fixed;top:35%;left:15%"};add_div(obj);$('tva_detail_id').innerHTML=req.responseText;req.responseText.evalScripts();remove_waiting_box();}});}
function check_param_tva()
{$("tva_id").style.borderColor="inherit";$("tva_code").style.borderColor="inherit";if($('tva_id').value=="0"){$("tva_id").style.borderColor="red";smoke.alert("Erreur");return false;}
if($('tva_code').value==""){smoke.alert("Erreur");$("tva_code").style.borderColor="red";return false;}
return true;}
function tva_parameter_add()
{waiting_box();new Ajax.Request("ajax.php",{parameters:{gDossier:dossier,plugin_code:plugin_code,ac:ac,action:"tva_parameter_add"},method:"get",onSuccess:function(req)
{var obj={id:'tva_detail_id',"cssclass":"inner_box","style":"width:auto;position:fixed;top:35%;left:15%"};add_div(obj);$('tva_detail_id').innerHTML=req.responseText;req.responseText.evalScripts();remove_waiting_box();}});}
function tva_parameter_delete(id)
{smoke.confirm("Effacement ?",function(e)
{if(e)
{waiting_box();new Ajax.Updater($("row"+id),"ajax.php",{method:"get",parameters:{"pt_id":id,action:"tva_parameter_delete",gDossier:dossier,plugin_code:plugin_code,ac:ac}});remove_waiting_box();}});}
function history_delete(id)
{smoke.confirm("Effacement ?",function(e)
{if(e)
{waiting_box();new Ajax.Updater($("row"+id),"ajax.php",{method:"get",parameters:{"id":id,action:"history_delete",gDossier:dossier,plugin_code:plugin_code,ac:ac}});remove_waiting_box();}});}
function select_acc_file()
{waiting_box();new Ajax.Updater($("select_file_div"),"ajax.php",{method:"get",parameters:{action:"select_acc_file",gDossier:dossier,plugin_code:plugin_code,ac:ac},onSuccess:function(){remove_waiting_box();$("select_file_div").show();}});}
function set_acc_file(p_id,p_name)
{$("acc_file_h").value=p_id;$("acc_file").innerHTML=p_id+" "+p_name;$('select_file_div').hide();}
function add_anc_file()
{waiting_box();new Ajax.Updater($("select_file_div"),"ajax.php",{method:"get",parameters:{action:"add_anc_file",gDossier:dossier,plugin_code:plugin_code,ac:ac,selected:$("anc_file_h").value},onSuccess:function(){remove_waiting_box();$("select_file_div").show();}});}
function set_anc_file(p_id)
{new Ajax.Updater($("list_anc_file"),"ajax.php",{method:"get",parameters:{action:"set_anc_file",import_file_anc_id:p_id,gDossier:dossier,plugin_code:plugin_code,ac:ac},insertion:"bottom",onSuccess:function(){$("select_file_div").hide();if($("anc_file_h").value=="")
{$("anc_file_h").value+=p_id;}else{$("anc_file_h").value+=","+p_id;}}});}
function remove_anc_file(p_rowid)
{$("list_anc_file").removeChild($("elt"+p_rowid));update_anc_file();}
function update_anc_file()
{$("anc_file_h").value="";var list_anc_file=document.getElementById("list_anc_file");var nb_element=list_anc_file.childElementCount;var sep="";for(var i=0;i<nb_element;i++)
{$("anc_file_h").value+=sep+list_anc_file.children[i].getAttribute('import_id');sep=",";}}
function detail_acc(p_id)
{}
function detail_anc(p_id)
{}
<?php
namespace NoalyssImport; if (!defined('ALLOWED')) die('Appel direct ne sont pas permis'); ?>
<table class="result">
    <tr>
        <th>
<?= _("n°") ?>
        </th>
        <th>
<?= _("Fichier") ?>
        </th>
        <th>
<?= _("Date") ?>
        </th>
    </tr>
<?php
$nb=count($array); for ($i=0; $i<$nb; $i++): $even=($i%2==0)?' even ':' odd '; ?>
        <tr class="<?php echo $even; ?>">
            <td>
    <?= \HtmlInput::anchor_action($array[$i]['id'],"set_anc_file({$array[$i]['id']})" , uniqid(),"line");?>
            </td>
            <td>
    <?= $array[$i]['ifa_filename'] ?>
            </td>
            <td  >
    <?php echo h($array[$i]['str_date']) ?>
            </td>
        </tr>


    <?php
endfor; ?>
</table>

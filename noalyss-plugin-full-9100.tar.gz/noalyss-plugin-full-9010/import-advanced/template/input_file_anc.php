<?php
namespace NoalyssImport; if (!defined('ALLOWED')) die('Appel direct ne sont pas permis'); $file=new \IFile("file_operation"); ?>

<form method="POST" enctype="multipart/form-data" >
    <?php echo \HtmlInput::array_to_hidden(array('gDossier','ac','plugin_code','sa'), $_REQUEST)?>

    <div id="csv_div_id" >
    <?php  $csv2=new Impacc_Import_Anc_Csv(); $csv2->input_format(); ?>
    </div>
    <?php
 echo _('Fichier opérations analytique'), $file->input(); ?>
<?php
 echo \HtmlInput::submit("upload_anc", _("Sauve")) ?>
</form>


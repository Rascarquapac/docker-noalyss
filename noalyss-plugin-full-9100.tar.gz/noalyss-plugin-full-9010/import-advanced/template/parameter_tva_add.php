<?php
namespace NoalyssImport; ?>
<div id="dtvaadd" class="inner_box" style="display:none">
	<h2 class="info">Ajout d'un taux de tva</h2>
	<form method="POST">

		<table>
			<tr>
				<td>
					TVA
				</td>
				<td>
					<?php $tva_id = new ITva_Popup('tva_id'); echo $tva_id->input()?>
				</td>
			</tr>
			<tr>
				<td>
					Taux dans le fichier <?php echo \Icon_Action::infobulle(50)?>
				</td>
				<td>
					<?php $w = new INum('pt_rate');echo $w->input();?>
				</td>
			</tr>
		</table>
		<?php echo \HtmlInput::submit("ftvaadd", "Ajout");?>
		<?php  $bt = new IButton("but_tva_close"); $bt->label = "Fermer"; $bt->javascript = " $('dtvaadd').hide()"; echo $bt->input(); ?>
	</form>

</div>
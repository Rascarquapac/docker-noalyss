<?php
namespace NoalyssImport; ?>
<p>
   <?php echo _("Chargement d'un fichier FEC en CSV ,");?>

</p>

<table>    
<tr>
<td><?php echo _("Séparateur");?> </td>
<TD> <?php echo $in_delimiter->input()?></td>
</tr>
<tr>
<td>
    <?php echo _("Création des postes comptables manquants")?>
</td>
<td>
    <?php echo $is_missing_account->input();?>
</td>
</tr>
<tr>
    <td>
        <?php echo _("Encodage")?>
    </td>
    <td>
        <?php echo $in_encoding->input()?>
    </td>
</tr>
</table>
<p>
    <?=_("Ces fichiers peuvent être créés avec cette extension")?>
    <a class="line" href="https://gitlab.com/noalyss/noalyss-export/-/wikis/home" target="_blank"><?=_("Export")?></a>
</p>
<div style="height:10em"></div>
<?php
namespace NoalyssImport; if (!defined('ALLOWED')) die('Appel direct ne sont pas permis'); ?>
<table class="result">
    <tr>
        <th>
<?= _("n°") ?>
        </th>
        <th>
<?= _("Fichier") ?>
        </th>
        <th>
<?= _("Type") ?>
        </th>
        <th>
<?= _("Date transfert") ?>
        </th>
        <th>
<?= _("Date") ?>
        </th>
    </tr>
<?php
$nb=count($array); for ($i=0; $i<$nb; $i++): $even=($i%2==0)?' even ':' odd '; ?>
        <tr class="<?php echo $even; ?>">
            <td>
    <?= \HtmlInput::anchor_action($array[$i]['id'],"set_acc_file({$array[$i]['id']},'{$array[$i]['i_filename']}')" , uniqid(),"line");?>
    
            </td>
            <td>
    <?= $array[$i]['i_filename'] ?>
            </td>
            <td>
    <?php echo h($array[$i]['i_type']) ?> / 
                <?php echo h($array[$i]['ledger_type']) ?>
            </td>
            <td>
    <?php echo h($array[$i]['simport']) ?>
            </td>

            <td sorttable_customkey="<?= $array[$i]['sorder_transfer'] ?>" >
    <?php echo h($array[$i]['stransfer']) ?>
            </td>
            <td>

            </td>
        </tr>


    <?php
endfor; ?>
</table>
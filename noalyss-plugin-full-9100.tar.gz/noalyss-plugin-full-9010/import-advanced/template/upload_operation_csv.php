<?php
namespace NoalyssImport; ?>
<p>
   <?php echo _("Chargement d'un fichier CSV , crée depuis Calc (OpenOffice.org ou libreoffice)");?>
<a class="line" href="http://download.noalyss.eu/contrib/import_avance/exemple" target="_blank"><?php echo _("Fichiers exemples")?></a>
</p>
<p>
    <?=_("Ces fichiers peuvent être créés avec cette extension")?>
    <a class="line" href="https://gitlab.com/noalyss/noalyss-export/-/wikis/home" target="_blank"><?=_("Export")?></a>
</p>
<table>    
<tr>
<td>
   <?php echo _("Type de journal");?>
</td>
<td>
    <?php echo $in_ledger->input()?>
</td>    
    
</tr>
<tr>
<td><?php echo _("Séparateur");?> </td>
<TD> <?php echo $in_delimiter->input()?></td>
</tr>

</tr>
<tr>
<td><?php echo _("Format de date") , \Icon_Action::infobulle(1077);?> </td>
<TD> <?php echo $in_date_format->input()?></td>
</tr>


<tr>
<td><?php echo _("Encodage");?></td>
<TD> <?php echo $in_encoding->input()?></td>
</tr>
<tr>
<td>  <?php echo _("Texte entouré par");?></td>
<TD>
    <?php echo $in_surround->input()?></td>
</td>
</tr>
<tr>
<td>  <?php echo _("Décimale");?></td>
<TD>
    <?php echo $in_decimal->input()?>
</td>
</tr>
<tr>
    <td>
        <?php echo _("Séparateur de millier");?>
    </td>
    <td>
        <?php echo $in_thousand->input()?></td>
    </td>
</tr>

</table>
<div style="height:10em"></div>
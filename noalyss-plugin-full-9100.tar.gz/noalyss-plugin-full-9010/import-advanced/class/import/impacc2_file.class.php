<?php
namespace NoalyssImport; require_once DIR_IMPORT_ACCOUNT."/class/import/impacc2_csv.class.php"; require_once DIR_IMPORT_ACCOUNT."/class/import/impacc2_fec.class.php"; require_once DIR_IMPORT_ACCOUNT."/class/impacc2_operation.class.php"; require_once DIR_IMPORT_ACCOUNT."/database/impacc2_import_file_sql.class.php"; require_once DIR_IMPORT_ACCOUNT."/database/impacc2_import_csv_sql.class.php"; class Impacc_File { static $aformat=array(1=>"CSV",2=>"FEC"); var $format; var $filename; var $import_file; function __construct($p_format) { if ( !in_array($p_format,["CSV","FEC"])){ throw new \Exception(_("IMPACCFILECONSTRUCTOR")); } $this->format=$p_format; } function save_file() { if (trim($_FILES['file_operation']['name'])=='') { alert(_('Pas de fichier donné')); return -1; } $this->filename=tempnam($_ENV['TMP'], 'upload_'); if (!move_uploaded_file($_FILES["file_operation"]["tmp_name"], $this->filename)) { throw new \Exception(_("Fichier non sauvé"), 1); } $cn=\Dossier::connect(); $imp=new \Impacc_Import_file_SQL($cn); $imp->setp('i_tmpname', $this->filename); $imp->setp('i_filename', $_FILES['file_operation']['name']); $imp->setp("i_type",$this->format); $imp->insert(); $cn->exec_sql("update impacc2.import_file set i_date_transfer=now() where id=$1", array($imp->id)); $this->import_file=$imp; $this->impid=$imp->getp("id"); try { $file=Impacc_File::build($this->impid); $file->set_import($this->impid); $file->set_setting(); $file->check_setting(); $file->save_setting(); } catch (\Exception $ex) { record_log($ex->getMessage()); record_log($ex->getTraceAsString()); echo _("Format invalide")," : ",$ex->getMessage(); throw $ex; } } function load($p_import_id) { $cn=\Dossier::connect(); $this->import_file=new \Impacc_Import_file_SQL($cn,$p_import_id); $this->impid=$p_import_id; } static function new_object($p_import_id) { $cn=\Dossier::connect(); $import_file=new \Impacc_Import_file_SQL($cn,$p_import_id); if ( $import_file->i_type=="CSV") { $res=new Impacc_File("CSV"); }elseif ( $import_file->i_type=="FEC") { $res=new Impacc_File("FEC"); }else { throw new \Exception("IMPACCFILE01"._("Type invalide")) ; } $res->import_file=$import_file; $res->impid=$p_import_id; return $res; } static function build($p_import_id) { $cn=\Dossier::connect(); $import_file=new \Impacc_Import_file_SQL($cn,$p_import_id); if ( $import_file->i_type=="CSV") { $res=new Impacc_CSV(); }elseif ( $import_file->i_type=="FEC") { $res=new Impacc_FEC(); }else { throw new \Exception("IMPACCFILE01"._("Type invalide")) ; } $res->set_import($p_import_id); return $res; } function record() { $operation=new Impacc_Operation(); $operation->record_file($this); $cn=\Dossier::connect(); $cn->exec_sql("update impacc2.import_file set i_date_transfer=now() where id=$1", array($this->import_file->id)); } function check() { $operation=new Impacc_Operation(); $operation->format=$this->import_file->i_type; $operation->check($this); } function result() { $operation =Impacc_File::build($this->import_file->id); $operation->result($this); } function form_check($id) { $impacc_csv=self::build($id); return $impacc_csv->check_form($id); } function result_transfer() { $cn=\Dossier::connect(); $operation=Impacc_File::build($this->import_file->id); $operation->load_import($this->import_file->id); $operation->result($this); } static function get_file() { $cn=\Dossier::connect(); $array=$cn->get_array( "
                 select   
                 import_file.id,
                 i_filename,
                 i_type,
                 to_char(i_date_transfer,'DD.MM.YY HH24:MI') as stransfer,
                 to_char(i_date_import,'DD.MM.YY HH24:MI') as simport,
                 to_char(i_date_transfer,'YYYYMMDDHHMI') as sorder_transfer,
                 ledger_type
                 from 
                 impacc2.import_file
                 left join impacc2.import_csv on (import_file.id=import_csv.import_id)
                 left join impacc2.import_fec on (import_file.id=import_fec.import_id)
                 order by i_date_transfer desc
                " ); return $array; } static function get_all_file() { $cn=\Dossier::connect(); $array=$cn->get_array( "
                 select   
                 import_file.id,
                 i_filename,
                 i_type,
                 to_char(i_date_transfer,'DD.MM.YY HH24:MI') as stransfer,
                 to_char(i_date_import,'DD.MM.YY HH24:MI') as simport,
                 to_char(i_date_transfer,'YYYYMMDDHHMI') as sorder_transfer,
                 ledger_type
                 from 
                 impacc2.import_file
                 left join impacc2.import_csv on (import_file.id=import_csv.import_id)
                 left join impacc2.import_fec on (import_file.id=import_fec.import_id)
                 union 
                 select 
                 	id,
                 	ifa_filename,
                 	'ANC',
                 	 to_char(ifa_date,'DD.MM.YY HH24:MI') ,
                 	'',
	                  to_char(ifa_date,'YYYYMMDDHHMI') as sorder_transfer,
                	''
                 from impacc2.import_file_anc
                 order by 6 desc
                " ); return $array; } static function display_list() { $array=Impacc_File::get_all_file(); require_once DIR_IMPORT_ACCOUNT."/template/history_file.php"; } function delete($id) { $cn=\Dossier::connect(); $cn->exec_sql("delete from impacc2.import_file where id=$1",array($id)); } static function select_file() { $array=Impacc_File::get_file(); require_once DIR_IMPORT_ACCOUNT."/template/select-acc-file.php"; } } ?>

<?php
namespace NoalyssImport; require_once DIR_IMPORT_ACCOUNT.'/class/import/impacc2_import_anc_csv.class.php'; require_once DIR_IMPORT_ACCOUNT.'/class/import/impacc2_file.class.php'; class Impacc_Transfer { private $acc_id; private $a_anc_id; private $transfer_log_id; function __construct($p_import_acc_id, $pa_import_anc_id="") { if (isNumber($p_import_acc_id)==0) throw new Exception(_("Paramètre invalide")); $this->acc_id=$p_import_acc_id; if ($pa_import_anc_id!="") { $this->a_anc_id=preg_split("/,/", $pa_import_anc_id); $this->a_anc_id=array_unique($this->a_anc_id); } else { $this->a_anc_id=array(); } $this->tranfer_log_id=0; } function confirm() { echo '<form method="post" onsubmit="waiting_box();return true;">'; echo \HtmlInput::array_to_hidden(['sa', 'gDossier', 'plugin_code', 'ac', 'acc_file_h', 'anc_file_h'], $_REQUEST); echo \HtmlInput::hidden("sb", "transfer"); echo \HtmlInput::submit("transfer", _("Confirme transfert")); echo '</form>        '; $impacc_file=Impacc_File::new_object($this->acc_id); $this->correct_case(); $impacc_file->check(); $impacc_file->result(); $nb_acc=count($this->a_anc_id); for ($i=0; $i<$nb_acc; $i++) { $idx=$this->a_anc_id[$i]; $impacc_import_anc_csv=new Impacc_Import_Anc_Csv($idx); $impacc_import_anc_csv->check(); $impacc_import_anc_csv->result(); } echo '<form method="post">'; echo \HtmlInput::array_to_hidden(['sa', 'gDossier', 'plugin_code', 'ac', 'acc_file_h', 'anc_file_h'], $_REQUEST); echo \HtmlInput::hidden("sb", "transfer"); echo \HtmlInput::submit("transfer", _("Confirme transfert")); echo '</form>        '; } function transfer_file() { $a_row=$this->transfer_acc(); } function correct_case() { $cn=\Dossier::connect(); } function transfer_acc() { $impacc_file=Impacc_File::new_object($this->acc_id); $cn=\Dossier::connect(); if ( $impacc_file->format=="CSV") { $nb_row=$this->transfer_acc_csv(); } elseif ( $impacc_file->format=="FEC") { $nb_row=$this->transfer_acc_fec(); } else { throw new Exception(_("TRANS01.Erreur transfert")); } $import_file=new \Impacc_Import_file_SQL($cn,$this->acc_id); $import_file->setp("i_date_import",date("d.m.Y H:i:s")); $import_file->update(); printf(_("Opérations transférées %s"),$nb_row); } private function make_csv_class(\Acc_Ledger $p_ledger) { switch ($p_ledger->get_type()) { case 'ACH': $obj=new Impacc_Csv_Purchase(); break; case 'VEN': $obj=new Impacc_Csv_Sale(); break; case 'ODS': $obj=new Impacc_Csv_Misc_Operation(); break; case 'FIN': $obj=new Impacc_Csv_Bank(); break; default : throw new Exception(_('type journal inconnu')); } return $obj; } private function transfer_acc_csv() { $cn=\Dossier::connect(); $cn->start(); try { $sql="
                    with rejected as ( SELECT distinct id_code_group 
                                        FROM impacc2.import_detail a
                                        where 
                                        import_id=$1
                                        and (id_status != 0 or trim(COALESCE(id_message,'')) !='')
                                        ) 
                    select distinct id_code_group ,id_date_format_conv, import_id,ledger_code.jrn_def_id
                    from 
                        impacc2.import_detail 
                        join impacc2.ledger_code on (id_ledger_code=ledger_code)
                    where 
                        import_id=$1 
                      and id_code_group not in (select coalesce(id_code_group,'') from rejected)

                    order by id_date_format_conv asc
                    "; $a_group=$cn->get_array($sql, [$this->acc_id]); $nb_row=count($a_group); for ($i=0; $i<$nb_row; $i++) { $ledger=Impacc_Tool::ledger_factory($a_group[$i]['jrn_def_id']); $impacc_csv=$this->make_csv_class($ledger); $a_anc_operation=$this->anc_to_array($a_group[$i]['id_code_group']); $a_insert=$impacc_csv->insert($a_group[$i], $ledger,$a_anc_operation); } $cn->commit(); return $nb_row; } catch (Exception $exc) { echo $exc->getMessage(); error_log($exc->getTraceAsString()); $cn->rollback(); throw $exc; } } function anc_to_array($p_group_id) { if ($this->a_anc_id==NULL) { return []; } $cn=\Dossier::connect(); $str_list=join(",", $this->a_anc_id); $a_anc_row=$cn->get_array("select distinct
            ida_amount,
            import_id,
            import_file_anc_id, 
            id_status,
            id_analytic_ref,
            id_code_group,
            ida_anc_account
            id_label,
            pa_id,
            id_amount_novat,
            import_detail_id,
            ida_anc_account,
            po_id
        from  
           impacc2.v_analytic_operation
        where
           import_id=$1 
           and id_code_group=$2
           and  import_file_anc_id in ($str_list)
           order by pa_id,id_analytic_ref", [ $this->acc_id, $p_group_id ]); $nb_anc_row=count($a_anc_row); if ($nb_anc_row==0) { return []; } $a_ancrow_result=[]; $a_operation=$cn->get_array("select id,id_date
                                from 
                                    impacc2.import_detail as id1
                                where  
                                    id_code_group=$1
                                    and id1.import_id=$2", [$p_group_id, $this->acc_id]); $a_pa_id=explode(",", $cn->make_list("select pa_id from plan_analytique order by pa_id ")); $a_ancrow_result['pa_id']=$a_pa_id; $a_hplan=[]; $idx=0; $operation_idx=0; $nb_operation = count($a_operation); for ($e=0; $e< $nb_operation; $e++) { $a_row_operation= $cn->get_array("select distinct
                                ida_amount,
                                import_id,
                                import_file_anc_id, 
                                id_status,
                                id_analytic_ref,
                                id_code_group,
                                ida_anc_account
                                id_label,
                                pa_id,
                                id_amount_novat,
                                import_detail_id,
                                ida_anc_account,
                                po_id
                            from  
                               impacc2.v_analytic_operation
                            where
                               import_id=$1 
                               and id_code_group=$2
                               and  import_file_anc_id in ($str_list)
                               and import_detail_id=$3
                               order by pa_id,id_analytic_ref", [ $this->acc_id, $p_group_id, $a_operation[$e]['id'] ]); if (empty($a_row_operation)) continue; $a_data=$a_row_operation; $nb_data=count($a_row_operation); $n_plan=count($a_pa_id); $a_plan=[]; if (DEBUGIMPORTADV > 0) { echo h1("a_data "); var_dump($a_row_operation); } $max_row=0; for ($k=0; $k<$n_plan; $k++) { $tmp_max=$cn->get_value("select count(*) 
                    from 
                        impacc2.v_analytic_operation
                        join public.poste_analytique on (po_name=ida_anc_account)
                     where
                        import_id=$1 
                        and import_file_anc_id in ($str_list)
                        and id_code_group=$2
                        and import_detail_id=$3
                        and poste_analytique.pa_id=$4
                        ", [ $this->acc_id, $p_group_id, $a_row_operation[0]['import_detail_id'], $a_pa_id[$k] ]); if ($tmp_max>$max_row) { $max_row=$tmp_max; } } for ($j=0; $j<$max_row*$n_plan; $j++) { $a_plan[$j]=-1; } $pos=0; if (DEBUGIMPORTADV > 0) { echo h1("a_plan"); var_dump($a_plan); } $a_operation_axis=array(); for ($j=0; $j<$nb_data; $j++) { $idx_pa_id=$a_row_operation[$j]['pa_id']; if (DEBUGIMPORTADV > 0 ){ echo h2("idx_pa_id ".$idx_pa_id); var_dump($a_operation_axis); } $a_operation_axis[$idx_pa_id][]= $a_row_operation[$j]['po_id']; } for ($j = 0;$j < $n_plan;$j++) { $idx_pa_id=$a_pa_id[$j]; if ( isset($a_operation_axis[$idx_pa_id]) && ! empty ($a_operation_axis[$idx_pa_id])) { $nb_operation_axis=count($a_operation_axis[$idx_pa_id]); for ($k=0;$k < $nb_operation_axis;$k++) { $pos=$j+$k*$n_plan; $a_plan[$pos]=$a_operation_axis[$idx_pa_id][$k]; } } } if (DEBUGIMPORTADV > 0 ) { echo h1("a_operation_axis"); var_dump($a_operation_axis); } $operation_idx=$e; $a_ancrow_result["hplan"][$e]=$a_plan; $a_ancrow_result["op"][$e]=$operation_idx; $a_unique_used_analytic_plan=array_unique(array_column($a_anc_row, "pa_id")); if (count($a_unique_used_analytic_plan)>0) { $tmp_unique=[]; $idx=0; foreach ($a_unique_used_analytic_plan as $key=> $value) { $tmp_unique[$idx]=$value; $idx++; } $a_unique_used_analytic_plan=$tmp_unique; } $idx=0; $a_done=[]; if (DEBUGIMPORTADV > 0) { echo h1("a_unique_used_analytic_plan"); var_dump($a_unique_used_analytic_plan); } for ($x=0; $x<count($a_unique_used_analytic_plan); $x++) { for ($j=0; $j<$nb_data; $j++) { if (in_array($a_unique_used_analytic_plan[$x], $a_done)==FALSE&&isNumber($a_row_operation[$j]['ida_amount'])==1) { $a_ancrow_result['val'][$e][$idx]=$a_row_operation[$j]['ida_amount']; $idx++; } } } if (DEBUGIMPORTADV > 0) { echo h1('$a_ancrow_result'); var_dump($a_ancrow_result); } } if (DEBUGIMPORTADV > 0) { echo h1('final $a_ancrow_result'); var_dump($a_ancrow_result); } return $a_ancrow_result; } private function transfer_acc_fec() { $cn=\Dossier::connect(); try { $cn->start(); $sql="
                    with rejected as ( SELECT distinct id_code_group 
                                        FROM impacc2.import_detail a
                                        where 
                                        import_id=$1
                                        and (id_status != 0 or trim(COALESCE(id_message,'')) !='')
                                        ) 
                    select distinct id_code_group ,id_date_format_conv, import_id,ledger_code.jrn_def_id
                    from 
                        impacc2.import_detail 
                        join impacc2.ledger_code on (id_ledger_code=ledger_code)
                    where 
                        import_id=$1 
                        and id_code_group not in (select coalesce(id_code_group,'') from rejected)
                    order by id_date_format_conv asc
                    "; $a_group=$cn->get_array($sql, [$this->acc_id]); $nb_row=count($a_group); $impacc_fec=new Operation_Fec(); Impacc_FEC::create_accounting($this->acc_id); for ($i=0; $i<$nb_row; $i++) { $ledger=new \Acc_Ledger($cn,$a_group[$i]['jrn_def_id']); $a_insert=$impacc_fec->insert($a_group[$i], $ledger); } $cn->commit(); return $nb_row; } catch (Exception $exc) { echo $exc->getMessage(); error_log($exc->getTraceAsString()); $cn->rollback(); throw $exc; } } } 
--- Facturation ---
1. Télécharger les factures en un seul fichier compressé
2. Régénérer les factures
3. Envoi des factures avec conversion PDF


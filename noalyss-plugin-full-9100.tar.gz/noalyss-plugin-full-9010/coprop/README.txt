Extension pour les copropriétés

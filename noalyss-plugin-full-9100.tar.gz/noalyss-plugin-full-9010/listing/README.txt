
Il faut absolument installer le plugin Rapport Avancé avant

You have to install the Advanced Report plugin before using this one

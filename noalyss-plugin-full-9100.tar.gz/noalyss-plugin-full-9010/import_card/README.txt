Skeleton of a plugin. It contains the structure and example.

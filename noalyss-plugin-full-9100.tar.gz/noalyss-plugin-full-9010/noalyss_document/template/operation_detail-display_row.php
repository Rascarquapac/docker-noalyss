<?php
/*
 *   This file is part of NOALYSS.
 *
 *   PhpCompta is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   PhpCompta is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with PhpCompta; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
// Copyright (2002-2022) Author Dany De Bontridder <danydb@noalyss.eu>

if (!defined('ALLOWED'))
    die('Appel direct ne sont pas permis');

/**
 * @file
 * @brief display one row per item for purchase 
 */
global $g_parameter;

$novat=bcsub($tvac->value??0,$amount_vat->value ??0,2);
?>
<p>
  
    <?= $card_purchase->input() ?>
    <?= $card_purchase->search() ?>
    <?= $tvac->input() ?>
    <?= $code_tva->input() ?>
    <?=$amount_vat->input()?>

    <?=\HtmlInput::hidden("amount_novat".$p_document_id."t".$p_loop,$novat)?>
    <?php    if ($g_parameter->MY_ANALYTIC!='nu') :?>
    <?php
        $div="div_{$p_ident}_{$p_loop}";
        ?>
        <button class='smallbutton'
            onclick="<?=sprintf("%s.show();anc_refresh_remain('%st%s',%s);return false;",$div,$p_ident,$p_loop,$p_loop)?>">
            C. Analytique <?=\Icon_Action::show_icon(uniqid(),""        );?>
        </button>

        <div class="" id="<?=$div?>" class="inner_box" style="display: none;margin-left:3rem;background-color: ghostwhite;justify-content: center;border:1px solid navy;padding: 1px">

        <?php
        echo \HtmlInput::hidden($remain_anc_name,bcsub($tvac->value,$amount_vat->value,2));
        ?>
        <h2 class="title"><?=_("Analytique")?></h2>
        <?php

        \Noalyss\Dbg::echo_var(1,"loop $p_loop");
        \Noalyss_Document\Analytic::display_row($p_document_id,$p_loop,$p_readonly,$p_ident);
        ?>
        <div>
            <?php echo \HtmlInput::button_hide($div);         ?>
        </div>
    </div>
    <?php endif;    ?>
</p>

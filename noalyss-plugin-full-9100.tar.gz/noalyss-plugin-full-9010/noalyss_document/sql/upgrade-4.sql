begin;
alter table noalyss_document.acc_operation add ao_json text;


insert into noalyss_document.version values(5,'New : ANC ',now());
commit;
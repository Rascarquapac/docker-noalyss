<?php
namespace NoalyssImport; require_once NOALYSS_INCLUDE."/lib/itva_popup.class.php"; $gDossier=\Dossier::id(); echo \HtmlInput::title_box(_("TVA"), "tva_detail_id"); ?>
<script>

</script>    
<form method="post" onsubmit="return check_param_tva();return false;">
    <ol style="list-style-type: none">
        <ul>
            <?php  echo _("TVA Noalyss") , " " ; $tva_popup=new \ITva_Popup("tva_id",$tva_id); $tva_popup->set_attribute("gDossier", $gDossier); echo $tva_popup->input(); echo $label," "; echo $comment; ?>
        </ul>
        <ul>
            <?php  echo _("Code TVA") ,' '; $tva_code=new \IText("tva_code",$tva_code); echo $tva_code->input(); ?>
        </ul>
    </ol>
    <?php
 echo \HtmlInput::request_to_hidden(array("gDossier","ac","plugin_code","sa")); echo \HtmlInput::hidden("pt_id", $id); ?>
    <ul class="aligned-block">
        <li>
            <?php echo \HtmlInput::submit("save", _("Valider"));?>
        </li>
        <li>
            <?php echo \HtmlInput::button_close("tva_detail_id");?>
        </li>
    </ul>
</form>

    
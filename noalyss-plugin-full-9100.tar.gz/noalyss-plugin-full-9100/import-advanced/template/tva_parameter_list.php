<?php
namespace NoalyssImport; $nb=count($ret); ?>
<table class="result">
    <tr>
        <th>
            <?php echo _("Label TVA Noalyss") ?>
            
        </th>
        <th>
            <?php echo _("Code TVA du CSV") ?>
        </th>
        <th>
            <?php echo _("Description TVA Noalyss") ?>
            
        </th>
        <th>
            <?php echo _("Taux TVA") ?>
            
        </th>
    </tr>
    <?php for ($i=0;$i<$nb;$i++):?>
    <tr id="row<?php echo $ret[$i]['pt_id']?>">
        
        <td>
            <?php echo \HtmlInput::anchor(h($ret[$i]['tva_label']), "", sprintf("onclick=\"tva_parameter_modify('%s')\"",$ret[$i]["pt_id"]))?>
        </td>
        <td>
            <?php echo $ret[$i]['tva_code']?>
        </td>
        </td>
        <td>
            <?php echo h($ret[$i]['tva_comment'])?>
        </td>
        <td>
            <?php echo h($ret[$i]['tva_rate'])?>
        </td>
        <td>
            <?php
 echo \Icon_Action::trash (uniqid(),sprintf("tva_parameter_delete('%s')",$ret[$i]['pt_id'])); ?>
        </td>
    </tr>
    <?php endfor;?>
</table>
<?php
 echo \HtmlInput::button_action(_("Ajout"), "tva_parameter_add()"); ?>
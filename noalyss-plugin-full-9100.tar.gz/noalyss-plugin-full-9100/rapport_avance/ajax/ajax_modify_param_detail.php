<?php
//This file is part of NOALYSS and is under GPL
//see licence.txt

// require_once '.php';
require_once  RAPAV_DIR.'/include/formulaire_param_detail.class.php';

$http=new \HttpInput();
$errcode = 0;
$fp_id = $http->get('fp_id', "string",-1);
$title="none";$comment="";$tab='none';
if ($fp_id != -1)
{
    $str="";
    $obj = new \rapav\Formulaire_Param_Detail_SQL($fp_id);
    switch ($obj->type_detail)
    {
        // --- Formula
        case 1:
            $obj = new \rapav\Rapav_Formula($fp_id);
            $title =_("Formule");
            $comment='
            <p>'.
                _('Entrez une formule avec des postes comptables, la syntaxe est la même que celle des "rapports"').
            '</p>
            <p>
                Exemple : [70%]*0.25+[71%]
            </p>';
            $tab='formula';
            break;
        // -- Poste comptable et code
        case 2:
            $obj = new \rapav\RAPAV_Account_Tva($fp_id);
            $title = _("Poste Comptable et code TVA");
            $tab='account_tva';
            $comment='<p>'.
	_('Entrez un poste comptable et un code de TVA').
	'</p>';
            break;
        // -- Calcul sur formulaire
        case 3:
            $obj = new \rapav\RAPAV_Compute($fp_id);
            $title = _("Compute");
            $tab='compute_id';
            $comment='<p>'.
	_('Entrez une formule avec des codes utilisés dans ce formulaire').
	'</p>';
            break;
        // -- Poste comptable
        case 4:
            $obj = new \rapav\RAPAV_Account($fp_id);
            $comment="";
            $tab='new_account_id';
            $title = _("Poste comptable");
            break;
        // Account with children
        case 6:
            $obj = new \rapav\RAPAV_Account($fp_id);
            $comment="";
            $tab='new_account_id';
            $title = _("Poste comptable");
            $str=HtmlInput::hidden("child", 1);
            break;
        // -- operation reconciliee
        case 5:
            $comment='';
            $obj = new \rapav\RAPAV_Reconcile($fp_id);
            $title = _("Opérations rapprochées");
            $tab="new_reconcile_id";
            break;
        default:
            $errcode = 1;
            echo \HtmlInput::title_box('Erreur', 'param_detail_div');
            echo _("Erreur type formule inconnu");
            break;
    }
} else
{
    $errcode = 2;
    echo \HtmlInput::title_box(_('Erreur'), 'param_detail_div');
    echo _('Paramètre invalide');
}

if ($errcode == 0)
{
  echo \HtmlInput::title_box($title, 'param_detail_div');
  echo '<div class="content" style="padding:10px">';
  echo '<span class="notice" id="param_detail_info_div"></span>';
  echo $comment;
  echo '<form method="post" onsubmit="save_param_detail(\'modify_param_detail_frm\');return false;" id="modify_param_detail_frm">';
  $obj->input();
  echo \HtmlInput::hidden('p_id',$obj->p_id);
  echo $str;
  echo \HtmlInput::hidden('tab',$tab);
  echo \HtmlInput::hidden('fp_id',$obj->fp_id);
  echo \HtmlInput::hidden('ac',$_REQUEST['ac']);
  echo \HtmlInput::hidden('plugin_code',$_REQUEST['plugin_code']);
  echo \Dossier::hidden();
  echo \HtmlInput::submit('save_modify_param_detail',_('Sauve'));
  echo '</form>';
  echo '</div>';
}
?>
